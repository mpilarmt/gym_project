from django.apps import AppConfig


class GymTrainerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gym_trainer'
